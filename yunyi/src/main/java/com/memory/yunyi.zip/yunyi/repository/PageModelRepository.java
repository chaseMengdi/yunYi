package com.memory.yunyi.repository;

import com.memory.yunyi.entity.PageModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PageModelRepository extends JpaRepository<PageModel, Integer> {

}
