package com.memory.yunyi.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import com.memory.yunyi.entity.Log;

import java.util.List;
import java.util.Optional;

@Service
public interface LogService {
    List<Log> getAllLog();

    void addLog(Log log);
    Integer  findAdminNow();
}
