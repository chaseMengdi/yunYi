package com.memory.yunyi.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class PageModel {

    @Id
    private Integer pageModelID;
    private String pageModelName;
    private String pictureLink;
    private Integer usageAmount;
    private String htmlLink;

    public PageModel(){

    }

    public PageModel(Integer pageModelID, String pageModelName, String pictureLink, Integer usageAmount, String htmlLink) {
        this.pageModelID = pageModelID;
        this.pageModelName = pageModelName;
        this.pictureLink = pictureLink;
        this.usageAmount = usageAmount;
        this.htmlLink = htmlLink;
    }

    public Integer getPageModelID() {
        return pageModelID;
    }

    public void setPageModelID(Integer pageModelID) {
        this.pageModelID = pageModelID;
    }

    public String getPageModelName() {
        return pageModelName;
    }

    public void setPageModelName(String pageModelName) {
        this.pageModelName = pageModelName;
    }

    public String getPictureLink() {
        return pictureLink;
    }

    public void setPictureLink(String pictureLink) {
        this.pictureLink = pictureLink;
    }

    public Integer getUsageAmount() {
        return usageAmount;
    }

    public void setUsageAmount(Integer usageAmount) {
        this.usageAmount = usageAmount;
    }

    public String getHtmlLink() {
        return htmlLink;
    }

    public void setHtmlLink(String htmlLink) {
        this.htmlLink = htmlLink;
    }
}
