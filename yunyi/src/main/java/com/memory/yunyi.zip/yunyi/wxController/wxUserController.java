package com.memory.yunyi.wxController;
import com.memory.yunyi.entity.VisitInfo;
import com.memory.yunyi.entity.userPageContent;
import com.memory.yunyi.service.UserService;
import com.memory.yunyi.entity.User;
import com.memory.yunyi.service.VisitInfoService;
import com.memory.yunyi.service.userPageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/")
public class wxUserController {
    @Autowired
    private UserService userService;
    @Autowired
    private VisitInfoService visitInfoService;
    @Autowired
    private userPageService pageService;

    @GetMapping("/wxGetUserList")
    public List<User> getUserList() {
        List<User> list = userService.getAllUser();
        return list;
    }

    @PostMapping("/wxLogin")
    public User exist(@RequestBody User user) {
        return userService.login(user.getUserID(), user.getPassword());
    }

    @PostMapping("/wxRegister")
    public User reg(@RequestBody User user) {
       VisitInfo v =  new VisitInfo(user.getUserID(),0,0,0,0);
        visitInfoService.add(v);
        userPageContent page = new userPageContent();
        page.setUserID(user.getUserID());
        page.setModelID(1);
        pageService.renew(page);
        return userService.reg(user);
    }

    @PostMapping("/wxUpdate")
    public void update(@RequestBody User user){
        userService.update(user);
    }

}