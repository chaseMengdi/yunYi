package com.memory.yunyi.wxController;
import com.memory.yunyi.service.UserService;
import com.memory.yunyi.entity.User;
import com.memory.yunyi.entity.VisitInfo;
import com.memory.yunyi.service.VisitInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/")
public class wxLikeController {
    @Autowired
    private VisitInfoService visitInfoService;
    @Autowired
    private UserService userService;


    @PostMapping("/wxDecLikeById")
    public VisitInfo decById(@RequestBody Integer id) {
        return visitInfoService.decLike(id);
    }

    @PostMapping("/wxLikeById")
    public VisitInfo incById(@RequestBody Integer id) {
        return visitInfoService.incLike(id);
    }

    @PostMapping("/wxReportById")
    public VisitInfo reportById(@RequestBody Integer id) {
        return visitInfoService.incReport(id);
    }

    @GetMapping("/wxDescListByLike")
    public List<VisitInfo> listByLike() {
        return visitInfoService.DescByLike();
    }

    @PostMapping("/wxListByHometown")
    public List<VisitInfo> listByHometown(@RequestBody Integer id) {
        return visitInfoService.ListByHometown(userService.findByID(id).getHometown());
    }



}