package com.memory.yunyi.wxController;
import com.memory.yunyi.entity.VisitInfo;
import com.memory.yunyi.service.CommentService;
import com.memory.yunyi.service.UserService;
import com.memory.yunyi.service.VisitInfoService;
import com.memory.yunyi.service.userPageService;
import com.memory.yunyi.entity.userPageContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/")
public class wxUpgController {
    @Autowired
    private userPageService pageService;
    @Autowired
    private UserService userService;
    @Autowired
    private VisitInfoService visitInfoService;
    @Autowired
    private CommentService commentService;


//    @PostMapping("/wxGetUpgById")
//    public userPageContent get(@RequestBody Integer id){
//        return  service.findByID(id).get();
//    }

    @PostMapping("/wxGetUpgById")
    public Map<String,Object> get(@RequestBody Integer id){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("content",pageService.findByID(id));
        map.put("user",userService.findByID(id));
        map.put("visitInfo",visitInfoService.findById(id));
        map.put("comment",commentService.listByTimeForOne(id));
        return map;
  }

  @PostMapping("/wxSaveContent")
  public userPageContent save(@RequestBody userPageContent u){
      return pageService.renew(u);
          }

   @PostMapping("/setModel")
    public void set(@RequestBody userPageContent u){
         pageService.setModelId(u.getModelID(),u.getUserID());
   }
}
